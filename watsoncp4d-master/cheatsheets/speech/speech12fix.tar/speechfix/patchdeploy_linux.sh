oc scale deploy $1 --replicas=0
oc get deploy $1 -o yaml > tmp.yaml && sed -i "s/opencontent-minio-client\:1.0.3/opencontent-minio-client\:1.0.5/g" tmp.yaml && kubectl replace -f tmp.yaml && rm tmp.yaml
oc scale deploy $1 --replicas=1
