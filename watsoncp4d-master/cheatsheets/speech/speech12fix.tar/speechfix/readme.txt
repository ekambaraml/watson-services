Included in this archive are sample definitions for minio and postgres secrets, the portworx-sc storageclass, and a shell script used to patch deployments that are attempting to pull the wrong opencontent-minio-client image. Internal use only, do not distribute

The secrets should be used as reference, for production please change the values for security purposes.

The fix instructions are as follows:
Install as usual. The images should transfer correctly and speech will begin to deploy. Eventually, some pods will fail with an Init:ImagePullBackOff error. They will likely be the STT runtime, TTS runtime, and STT AM patcher pods. Identify the name of the deployment responsible for each pod.

`oc get deployments | grep <instance name> | awk '{print $1}'`

<instance name> is the value provided to the `--instance` flag in the install command.

Run this command, providing the deployment name from above as the only argument:

For MacOS (darwin)
./patchdeploy_darwin.sh <deployment_name>

For Linux:
./patchdeploy_linux.sh <deployment_name>

This will scale the deployment to 0 replicas, modify the definition to reference the correct image tag, and scale it back up. Repeat for the remaining deployments The pods should come up healthy now and the installation will finish as normal
